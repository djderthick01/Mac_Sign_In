/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author djd51
 */
public class Report extends HttpServlet {
    private String ID;
    private String Course;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Report</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Report at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * This method is incomplete.
     * This method services a jquery request from a data page that wants to display the database data.
     * If an ID has been instantiated, the database is queried to find the student name, and all the sessions he/she 
     * has had at the MAC and displays the session date and corresponding session note for each.
     * If a course has been instantiated, the database is queried to find the total session times for this class in hours
     * and how many students have needed tutoring for this class.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                     response.setContentType("text/html");
             response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
       if(ID == null){   try {
           out.write("<table>"
                             + "<tr>"
                             + "<th><font face='arial'><br><h4>"
                             + Course
                             + "</h4><br></font></th></tr>"
                             + "<table align='center' border=1>"
                             + "<tr>"
                             + "<td>"
                             + "Unique Sessions: "
                             + "</td>"
                             + "<td>"
                             + database.GetCourseSessionsAsString(Course)
                             + "</td>"
                             + "</tr>"
                             + "<tr>"
                             + "<td>"
                             + "Time Studied: "
                             + "</td>"
                             + "<td>"
                             + database.GetMACUseAverage(Course)
                             + " mins"
                             + "</td>"
                             + "</tr>"
                             + "</table>");
                         } catch (Exception ex) {
                             Logger.getLogger(Report.class.getName()).log(Level.SEVERE, null, ex);
                         }
      }
       else{
                         try {
                             String num = ID.substring(3);
                             Student student = database.GetStudent(num);
                             Session[] student_sessions = database.getSessionDatesAndNotes(num);
                             Survey[] student_surveys = database.GetStudentSurveyDataFromID(num);
                              out.write("<table>"
                                         + "<tr>"
                                         + "<th><font face='arial'><br><h4>"
                                         + student.get_first() + " " + student.get_last()
                                         + "</h4><br></font></th></tr>");
                                       
                        for(int i =0;i<student_sessions.length;i++)
                        {
                            out.write("<table>"
                       
                                             + "<table align='center' border=1>"
                                             + "<tr>"
                                             + "<td>"
                                             + "Date: "
                                             + "</td>"
                                             + "<td>"
                                             + student_sessions[i].get_date()
                                             + "</td>"
                                             + "</tr>"
                                             + "<tr>"
                                             + "<td>"
                                             + "Notes: "
                                             + "</td>"
                                             + "<td>"
                                             + student_sessions[i].get_note()
                                             + "</td>"
                                             + "</tr>"
                                             + "</table>");
                        }
                       
                        for(int j = 0;j < student_surveys.length; j++)
                        {
                            out.write("<table>"
                       
                                             + "<table align='center' border=1>"
                                             + "<tr>"
                                             + "<td>"
                                             + "Date: "
                                             + "</td>"
                                             + "<td>"
                                             + student_surveys[j].Session_Date()
                                             + "</td>"
                                             + "</tr>"
                                             + "<tr>"
                                             + "<td>"
                                             + "Primary: "
                                             + "</td>"
                                             + "<td>"
                                             + student_surveys[j].get_primary()
                                             + "</td>"
                                             + "</tr>"                                            
                                             + "<tr>"
                                             + "<td>"
                                             + "Visit: "
                                             + "</td>"
                                             + "<td>"
                                             + student_surveys[j].get_Visit()
                                             + "</td>"
                                             + "</tr>"                                            
                                             + "<tr>"
                                             + "<td>"
                                             + "Wait: "
                                             + "</td>"
                                             + "<td>"
                                             + student_surveys[j].get_Wait()
                                             + "</td>"
                                             + "</tr>"                                          
                                             + "<tr>"
                                             + "<td>"
                                             + "Feedback: "
                                             + "</td>"
                                             + "<td>"
                                             + student_surveys[j].get_Feedback()
                                             + "</td>"
                                             + "</tr>"
                                             + "</table>");
                        }
                         } catch (Exception ex) {
                             Logger.getLogger(Report.class.getName()).log(Level.SEVERE, null, ex);
                         }
       } // do student stuff
       
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * This method is unfinished, but it takes information from the two forms on the admin 
     * page. Upon what is retrieved, the variables are instantiated for retrieval from doGet. 
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ID = request.getParameter("DataStudentId");
        Course = request.getParameter("DataCourseName");
        RequestDispatcher res = request.getRequestDispatcher("MAC_database.jsp");
        res.include(request, response);
      // RequestDispatcher rs = request.getRequestDispatcher("data.jsp");
      // rs.include(request, response);
        
    }// will service request when either a course is entered or an ID is entered

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
