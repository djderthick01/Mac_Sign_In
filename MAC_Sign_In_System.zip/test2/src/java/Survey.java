/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author djd51
 */
public class Survey {
    private String Primary_Service,Session_Date,Rate_Visit,Wait_Time,Feedback;
            public Survey(String Primary, String Date, String Visit, String Wait, String Feedback){
        Primary_Service = Primary;
        Session_Date = Date;
        Rate_Visit = Visit;
        Wait_Time = Wait;
        this.Feedback = Feedback;

    }
    
    public String get_primary(){
        return Primary_Service;}
    public String Session_Date(){
        return Session_Date;}
    public String get_Visit(){
        return Rate_Visit;}
    public String get_Wait(){
    return Wait_Time;}
    public String get_Feedback(){
    return Feedback;}
}
   

