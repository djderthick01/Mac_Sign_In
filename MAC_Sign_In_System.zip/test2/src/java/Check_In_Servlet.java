/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

/**
 *
 * @author djd51
 */
public class Check_In_Servlet extends HttpServlet {
    private String num;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Check_In_Servlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Check_In_Servlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * This servlet responds to a form submission from the check-in form of the MAC sign in page.
     * It makes sure the data is in an acceptable form and creates a session with the ID,Course, and time stamp to the database.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         num = null;
        String ID = request.getParameter("LogStudentId");
        String Course = request.getParameter("LogCourseName");
         if(ID.length() != 9){
                    JOptionPane.showMessageDialog(null,"YSU ID should be in form: Y00XXXXXX.");
                     RequestDispatcher rs = request.getRequestDispatcher("MAC_signin.html");
                    rs.include(request, response);}
                else if(!ID.startsWith("Y00")){
                    JOptionPane.showMessageDialog(null,"YSU ID should be in form: Y00XXXXXX.");
                    RequestDispatcher rs = request.getRequestDispatcher("MAC_signin.html");
                    rs.include(request, response);
                }
                else{
                    
            try {
                num = ID.substring(3);
               SimpleDateFormat DateFormat = new SimpleDateFormat("yyyyMMdd");             
        String TodayRaw  = DateFormat.format(new Date());
                SimpleDateFormat TimeFormat = new SimpleDateFormat("HHmmss");
           String RightNowRaw = TimeFormat.format(new Date());
           database.CreateSession(num, TodayRaw,RightNowRaw,Course);
           RequestDispatcher rs = request.getRequestDispatcher("MAC_questions.html");
           rs.include(request, response);
            } catch (Exception ex) {
                Logger.getLogger(Check_In_Servlet.class.getName()).log(Level.SEVERE, null, ex);
            }
                }    
         
         
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                      SimpleDateFormat DateFormat = new SimpleDateFormat("yyyyMMdd");             
        String TodayRaw  = DateFormat.format(new Date());
        try {
            String req = "";
            for(int i = 1;i < 8; i++){
            if(request.getParameter("services"+i) != null)
                req += request.getParameter("services"+i)+",";
                }
            System.out.println(req);
            System.out.println(num + TodayRaw + request.getParameter("services1")+request.getParameter("services2")+request.getParameter("services3")+request.getParameter("services4")+request.getParameter("services5")+request.getParameter("services6")+request.getParameter("services7") + request.getParameter("rate") + request.getParameter("wait") + request.getParameter("feedback"));
            database.SubmitStudentSurvey(num,TodayRaw,req,request.getParameter("rate"), request.getParameter("wait"), request.getParameter("feedback"));
        } catch (Exception ex) {
            Logger.getLogger(Check_In_Servlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        RequestDispatcher rs = request.getRequestDispatcher("MAC_signin.html");
           rs.include(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "This servlet acts as a listener to the check-in form on the homepage of this web application. "
                + "It does light error checking to the form data then attempts create session for the student connected to provided ID.";
    }// </editor-fold>

}
