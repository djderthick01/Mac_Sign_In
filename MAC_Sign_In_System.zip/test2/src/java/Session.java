/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author djd51
 */
public class Session {
    private String date,note;
        public Session(String date, String note){
        this.date = date;
        this.note = note;
    }
    
    public String get_date(){
        return date;}
    public String get_note(){
        return note;}

}
