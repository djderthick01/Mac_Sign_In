/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

/**
 *
 * @author djd51
 */
public class Admin_Serv extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Admin_Serv</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Admin_Serv at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * This method processes a jquery from MAC_jsp page which is requesting the active student sessions
     * to display on its page. It queries the database for the active sessions, then sends the dynamically allocated 
     * table to the page to be displayed.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
             response.setContentType("text/html");
             response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
                 try {
                     String[] list = database.Active_Session_IDs();
                     Student[] active = database.active_students(list);
                       //replace println with write
         out.write("<table>"
                             + "<tr>"
                             + "<th><font face='arial'><br><h4>Active Student Sessions</h4><br></font></th></tr>");
                     for(int i = 0; i < active.length; i++){
                     out.write("<tr><td><form action='Check_Out' method='POST'>"
                             + "<hr>"
                             + "<table align='center' border=0>"
                             + "<tr>"
                             + "<td><font face='arial'>"+ active[i].get_first() +" " + active[i].get_last() + "</font></td>"
                             + "<td align='center'>" + active[i].get_num() + "</td>"
                             + "</tr>"
                             + "<tr>"
                             + "<td>"
                             + "<div class='sg-question sg-type-multitext  sg-required'>"
                             + "<font face='arial'>"
                             + "<textarea class='autoExpand' name='Note'"
                             + " cols='50' rows='2' data-min-rows='2' placeholder='Write Session Comments Here'></textarea></td>"
                             + "</font>"
                             + "</div>"
                             + "<td align='center'>"
                             + "<font face='arial'>"
                            + "<input type='hidden' name='ID' value=" +active[i].get_num()+ ">"
                            + "<input type='hidden' name='Name' value='"+ active[i].get_first() +" " + active[i].get_last() + "'>"
                            + "<button class='sg-button sg-submit-button' type='submit' value='Check Out'> Check Out </button>"
                            + "</font>"
                            + "</td>"
                                    + "</tr>"
                                    + "</table>"
                                    + "</form>"
                                    + "</td>"
                                    + "</tr>");}
                     out.write("</table>");
                     //draw html table
                 } catch (Exception ex) {
                     Logger.getLogger(Admin_Serv.class.getName()).log(Level.SEVERE, null, ex);
                 }
       }
    

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * This method checks the authentication of the admin login and password.
     * Upon a correct entry, navigates the user to the active sessions page.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                 String user = request.getParameter("UserName"); // User Name
       String pass = request.getParameter("Password"); // Password
       if(pass.equals("meep") && user.equals("admin")){
           RequestDispatcher rs = request.getRequestDispatcher("MAC_adminpanel.jsp");
           rs.include(request, response);
       }
       else {
                      JOptionPane.showMessageDialog(null,"Incorrect Login Credentials");
           RequestDispatcher rs = request.getRequestDispatcher("MAC_adminpage.html");
                    rs.include(request, response);
       }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
