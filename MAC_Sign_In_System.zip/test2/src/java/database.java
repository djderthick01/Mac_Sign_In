
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Dylan Mikina
 * @Date 11/8/2018
 */
public class database {
    @SuppressWarnings("ConvertToTryWithResources")
    public static void main(String[] args) throws Exception{
       // String myString = " empty";
        
       // Scanner myScanner = new Scanner(System.in);
    
      //  System.out.println("pepe, \"booted up!\"");
//        String FirstName = " No First Name";
//        String LastName = " No Last Name ";
//        int IDNum = 13;
//        
//        FirstName = myScanner.nextLine();
//        LastName = myScanner.nextLine();
//        IDNum = myScanner.nextInt();
//       
//        System.out.println(" * * * * * * *");
//        System.out.println("First name set to: " + FirstName);
//        System.out.println("Last name set to: " + LastName);
//        System.out.println("ID number set to: " + IDNum);
//        System.out.println(" * * * * * * *");
//        
//        CreateTable();
//        SetStudentData(FirstName, LastName, IDNum);
//        GetStudentData(IDNum);
    //        Student Dylan = new Student();
    //        System.out.println(Dylan.GetFname(13));
    //        System.out.println(Dylan.GetLname(13));
      //     GetAllStudentData();
    }
    
    /**
     * This is the "Green piece of paper". This function store all data related to a session
     * @param IDNum
     * Student's ID number
     * @param Date
     * Date of tutoring
     * @param StartTime
     * Time tutoring started
     * @param EndTime
     * Time tutoring ended
     * @param Tutor
     * The name of the tutor who provided service
     * @param Term
     * The school term
     * @throws Exception 
     */
    public static void SetSessionData(int IDNum, String Date, String StartTime, String EndTime, String Tutor, String Term) throws Exception{
        try{
            Connection con = GetConnection();
                        
            PreparedStatement insert = con.prepareStatement("INSERT INTO SESSIONS(YSU_ID, SESSION_DATE, START_TIME, END_TIME, SESSTION_TUTOR, "
                + "SEMESTER_TERM) VALUES("+IDNum + "\", \"" +Date + "\", \""+StartTime + "\", \""+EndTime+ "\", \""+Tutor + "\", \""+Term + ");");
            insert.executeUpdate();
        }catch (Exception e){System.out.println("Exception while writing session data!");}
    }
    
    /**
     * Creates a new table **DEV USE ONLY!**
     * @throws Exception 
     */
    public static void CreateTable() throws Exception{
        try{
            Connection con = GetConnection();
            PreparedStatement create = con.prepareStatement("CREATE TABLE IF NOT EXISTS STUDENT(FIRST_NAME varchar(255), LAST_NAME varchar(255), YSU_ID INT, PRIMARY KEY(YSU_ID));");
            create.executeUpdate();
        
        }catch (Exception e){System.out.println("Exception while creating table!");}
        finally{
            System.out.println("Function \"CreatTable\" ran");
                    }
    }
    
    /**
     * Takes in first and last names and ID number for a new student, and adds them into a new row in the DB (STUDENT table)
     * @param FirstName
     * The student's first name
     * @param LastName
     * The student's last name
     * @param IDNum
     * the student's YSU ID number
     * @throws Exception 
     * If there is an error with data entry OR if there is a duplicate ID number
     */
    public static void SetStudentData(String FirstName, String LastName, String IDNum) throws Exception{
        try{   
            Connection con = GetConnection();
            Statement stmt = null;
                              stmt = con.createStatement();
      
      String sql = "INSERT INTO Student " +
                   "VALUES ('"+FirstName+"', '"+LastName+"', '"+IDNum+"');";
      stmt.executeUpdate(sql);
         //   PreparedStatement insert = con.prepareStatement("INSERT INTO STUDENT(FIRST_NAME, LAST_NAME, YSU_ID) VALUES(\""
            //    +FirstName + "\", \"" +LastName +"\", "+IDNum +");");
         //   insert.executeUpdate();
        }catch (Exception e){System.out.println("Unable to set student data!");}     

    }
    /**
     * Uses System.out to print ONE student's first and last names and YSU ID number.
     * @param IDNUM
     * The student's ID number
     * @throws Exception 
     */
    public static String GetStudentData(String IDNUM) throws Exception{
        try{
            Connection con = GetConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT FIRST_NAME, LAST_NAME, YSU_ID FROM STUDENT WHERE YSU_ID ="+IDNUM+";");
            if (rs.next()) {
                String lastName = rs.getString("LAST_NAME");
                String firstName = rs.getString("FIRST_NAME");
                String idNum = rs.getString("YSU_ID");
                return firstName+lastName+idNum;
            }
            else{
                return "N";
            }
        }catch (Exception e){System.out.println("Failed to get student data");}
        return "N";
    }
    
    /**
     * Uses System.out.println print first and last name and YSU ID number for all the students in the DB
     * @throws Exception 
     */
    public static void GetAllStudentData() throws Exception{
        try{
            Connection con = GetConnection();
            
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT FIRST_NAME, LAST_NAME, YSU_ID FROM STUDENT WHERE YSU_ID ;");
            
            while (rs.next()) {
                String lastName = rs.getString("LAST_NAME");
                String firstName = rs.getString("FIRST_NAME");
                String idNum = rs.getString("YSU_ID");
                System.out.println(lastName + ", "+firstName +", "+idNum+ "\n");
                
            }
        }catch (Exception e){System.out.println("Failed to get student data");}    
    }
    
    /**
     * A simple DB connection function. Username and Password must be hard coded into this function.
     * @return
     * This function returns null because it is talking directly to a MYSQL database.
     * @throws Exception 
     */
    public static Connection GetConnection() throws Exception{
        try{
            String driver = "com.mysql.cj.jdbc.Driver";
            String url = "jdbc:mysql://localhost:3306/mac/2";         //change "localhost" to IP of server AND "mac_for_testing" to DB name
            String username = "root";                                           //change "root" to username
            String password = "Repsforjesus11";                                 //change "DylanI$Great" to password
            Class.forName(driver);
            
            Connection Conn = DriverManager.getConnection(url,username,password);
            System.out.println("Connected");
            return Conn;
         } catch(ClassNotFoundException | SQLException e){System.out.println("e");}
        
           return null;
    }
    
    /**
     * Overloaded version of GetConnection that takes in Username and Password
     * @param USER
     * The end user's username.
     * @param PASS
     * The end user's password.
     * @return
     * This function returns null because it is talking directly to a MYSQL database.
     * @throws Exception if unable to connect. This could be a username/password mismatch OR an issue with connecting to the database.
     */
    public static Connection GetConnection(String USER, String PASS) throws Exception{
        try{
            String driver = "com.mysql.cj.jdbc.Driver";
            String url = "jdbc:mysql://localhost:3306/mac_for_testing";         //change "localhost" to IP of server AND "mac_for_testing" to DB name
            String username = USER;                                           //change "root" to username
            String password = PASS;                                 //change "DylanI$Great" to password
            Class.forName(driver);
            
            Connection Conn = DriverManager.getConnection(url,username,password);
            System.out.println("Connected");
            return Conn;
         } catch(ClassNotFoundException | SQLException e){System.out.println("e");}
        
           return null;
    }
    
    /**
     * Overloaded version of GetConnection that takes in Username, Password, and DB address
     * @param USER
     * The end user's username.
     * @param PASS
     * The end user's password.
     * @param HOST
     * The IP address and database name in the format:  IPAddress/databaseName
     * @return
     * This function returns null because it is talking directly to a MYSQL database.
     * @throws Exception if unable to connect. This could be a username/password mismatch OR an issue with connecting to the database.
     */
    public static Connection GetConnection(String USER, String PASS, String HOST) throws Exception{
        try{
            String driver = "com.mysql.cj.jdbc.Driver";
            String url = "jdbc:mysql://"+HOST;
            String username = USER;
            String password = PASS;
            Class.forName(driver);
            
            Connection Conn = DriverManager.getConnection(url,username,password);
            System.out.println("Connected");
            return Conn;
         } catch(ClassNotFoundException | SQLException e){System.out.println("e");}
        
           return null;
    }
    public static int get_size()throws Exception{
                try{
            Connection con = GetConnection();
            
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT count(*) AS size FROM sessions WHERE start_time IS NOT NULL and end_time IS NULL;");
            rs.next();
            int size = rs.getInt("size");
            return size;}
                catch (Exception e){System.out.println("Failed to get active sessions size");
    }
                return 0;
}
    	/**
     * Creates a session with current date and time and YSU_ID
     * @param UserIDIn
     * YSU ID number
     * @param DateIn
     * Todays date as a String in the form "yyyyMMdd"
     * @param RightNowIn
     * The current time in the form "HHmmss"
     * @param Course
     * @throws Exception
     * When it cannot connect to the database, or the date or time are formatted incorrectly
     */
    public static void CreateSession(String UserIDIn, String DateIn, String RightNowIn, String Course) throws Exception{
        
        try{
           
           Connection con = GetConnection();
           Statement stmt = con.createStatement();
           String insert = "INSERT INTO SESSIONS(YSU_ID, SESSION_DATE,START_TIME ,COURSE_NAME) VALUES ( '"+UserIDIn+"', '"+DateIn+ "', '"+RightNowIn+ "', '" +Course+ "');";
           stmt.execute(insert);
           
        } catch(ClassNotFoundException | SQLException e){System.out.println("CAN NOT CREATE SESSION");}
    }
    public static String[] Active_Session_IDs() throws Exception{
    int size = get_size();
    String[] list = new String[size+1];
    int count = 0;
        try{
            Connection con = GetConnection();
            
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT ysu_id FROM sessions WHERE start_time IS NOT NULL and end_time IS NULL;");
            while(rs.next()){
           list[count] = rs.getString("ysu_id");
           count ++;
            }
        }catch(ClassNotFoundException | SQLException e){System.out.println("Could not get active sessions");
        }
        return list;
    }
    public static Student[] active_students(String[] list){
    int size = list.length;
    Student[] slist = new Student[size];
    try{
    for(int i = 0;i < size; i++){
    slist[i] = GetStudent(list[i]);}
    }catch (Exception e){System.out.println("Failed to get active students");}
    return slist;}
     public static Student GetStudent(String IDNUM) throws Exception{
        try{
            Connection con = GetConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT FIRST_NAME, LAST_NAME, YSU_ID FROM STUDENT WHERE YSU_ID =" +"'"+IDNUM +"'"+";");
            if (rs.next()) {
                String lastName = rs.getString("LAST_NAME");
                String firstName = rs.getString("FIRST_NAME");
                String idNum = rs.getString("YSU_ID");
                Student data = new Student(firstName,lastName,idNum);
                return data;
            }
            else{
                return null;
            }
        }catch (Exception e){System.out.println("Failed to get student data");}
        return null;
    }
         /**
     * Takes in YSU ID and NOTES and updates the appropriate row with the new notes
     * @param inYSUId
     * YSU student ID
     * @param inNotes
     * The notes about the tutoring session. MAXIMUM 500 CHARECTERS
     * @throws Exception
     * If there is a Database connectivity issue, or if there is incorrect validating parameters.
     */
    public static void CheckOut(String inYSUId, String inNotes) throws Exception{
        try{
            
            //get current time
            SimpleDateFormat TimeFormat = new SimpleDateFormat("HHmmss");            
            String CurrentTime  = TimeFormat.format(new Date());
            
            //connect to DB
            Connection con = GetConnection();
            Statement stmt = con.createStatement();
            //update notes
            String sql = "UPDATE SESSIONS SET NOTES =  '"+inNotes+"'  WHERE YSU_ID = '"+inYSUId+"';";
            stmt.execute(sql);
            
            //update end time
            String sql2 = "UPDATE SESSIONS SET END_TIME = '"+CurrentTime+"' WHERE YSU_ID = '"+inYSUId+"';";
         
            stmt.execute(sql2);
            
         } catch(Exception e){System.out.println("e");}
    }
        //GetMACAverage methods, Returns an INT of how many hours were spent in the MAC
    /**
     * Quarries the database and returns the total number of minutes spent in the MAC
     * @return
     * The number of minutes spent in the MAC
     * @throws Exception 
     */
    public static int GetMACUseAverage() throws Exception{
        int Output = 0; 
        try{
            //connect to DB
            Connection con = GetConnection();
            
            //Statement for quirying database
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT TIMESTAMPDIFF(MINUTE, START_TIME, END_TIME) AS TimeLogged FROM SESSIONS;");
            
            // Convert to Java-usable String and set Output variable to reflect resaults
            while (rs.next()){
                Output = Output + rs.getInt(1);
            }       
        }catch (Exception e){System.out.println("Failed to get session data");} 
        return Output;
    }
    /**
     * Overloaded; Takes in a course name and returns the total number of minutes spent with that course.
     * @param inCourseName
     * The name of the course being researched.
     * @return
     * The total minutes spent in the given course.
     * @throws Exception 
     */
    public static int GetMACUseAverage(String inCourseName) throws Exception{
        int Output = 0; 
        try{
            //connect to DB
            Connection con = GetConnection();
            
            //Statement for quirying database
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT TIMESTAMPDIFF(MINUTE, START_TIME, END_TIME) AS TimeLogged FROM SESSIONS WHERE COURSE_NAME = '"+inCourseName+"';");
            
            // Convert to Java-usable String and set Output variable to reflect resaults
            while (rs.next()){
                Output = Output + rs.getInt(1);
            }       
        }catch (Exception e){System.out.println("Failed to get session data");} 
        return Output;
    }
        //GetCourseSession methods, Returns the number of times a certain course was covered in a session
    /**
     * Takes in the course name and returns the number of sessions that involved that course name AS A STRING.
     * @param inCourseName
     * The name of the course being counted
     * @return
     * STRING The number of sessions involving the inputed course name
     * @throws Exception 
     */
    public static String GetCourseSessionsAsString(String inCourseName) throws Exception{
        String Output = null;
        try{
            //connect to DB
            Connection con = GetConnection();
            
            //Statement for quirying database
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM SESSIONS WHERE COURSE_NAME = '" +inCourseName+ "';");
            
            // Convert to Java-usable String and set Output variable to reflect resaults
            rs.next();
            int count = rs.getInt(1);
            Output = Integer.toString(count);           
        }catch (Exception e){System.out.println("Failed to get session data");} 
        return Output;
    }
        /**
     * Takes in the course name and returns the number of sessions that involved that course name AS AN INT.
     * @param inCourseName
     * The name of the course being counted
     * @return
     * INT The number of sessions involving the inputed course name
     * @throws Exception 
     */
    public static int GetCourseSessionsAsInt(String inCourseName) throws Exception{
        int Output = -1;
        try{
            //connect to DB
            Connection con = GetConnection();
            
            //Statement for quirying database
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM SESSIONS WHERE COURSE_NAME = '" +inCourseName+ "';");
            
            // Convert to Java-usable INT and set Output variable to reflect resaults
            rs.next();
            Output = rs.getInt(1);           
        }catch (Exception e){System.out.println("Failed to get session data");} 
        return Output;
    }
        /**
     * \
     * @param YSUID
     * Student ID as a string
     * @param YSUID
     * @param Date
     * @param PrimaryService
     * First radial box, Primary reason for visit to MAC
     * @param RateVisit
     * Second radial box, Rate the visit at the MAC
     * @param WaitTime
     * Third radial box, Wait time before the student was helped
     * @param Feedback
     * Final box (only text box), Student can leave 500 chars of feedback here
     * @throws Exception
     * If unable to connect to the database, OR if the Primary Key has already been used
     */
        public static void SubmitStudentSurvey(String YSUID,String Date, String PrimaryService, String RateVisit, String WaitTime, String Feedback) throws Exception{
                try{

            //connect to DB
            Connection con = GetConnection();
            
            //update SURVEY
            Statement stmt = con.createStatement();
      
      
      String sql ="INSERT INTO SURVEY (YSU_ID, SESSION_DATE, PRIMARY_SERVICE, RATE_VISIT, WAIT_TIME, FEEDBACK)"
                    + "VALUES (\""+YSUID+"\", '"+Date+ "', \""+PrimaryService+ "\", \""+RateVisit+ "\", \""+ WaitTime+ "\", \""+Feedback+ "\");";
      stmt.execute(sql);

} catch(Exception e){System.out.println("Unable to set survey data (2)");}
        //    PreparedStatement insert = con.prepareStatement("INSERT INTO SURVEY (YSU_ID, DATE, PRIMARY_SERVICE, RATE_VISIT, WAIT_TIME, FEEDBACK)"
            //        + "VALUES ('"+YSUID+"', '"+Date+ "', '"+PrimaryService+ "', '"+RateVisit+ "', '"+ WaitTime+ "', '"+Feedback+ "');");
          //  insert.executeUpdate(); 
        }
        /**
     * 
     * @param YSUID
     * The YSU Student's ID number
     * @return
     * All Survey data, in rows and columns
     * @throws Exception 
     * When unable to connect to the Database
     */
    public static Survey[] GetStudentSurveyDataFromID(String YSUID) throws Exception{
            Survey[] slist = new Survey[database.getSurveySize(YSUID)];
            int count = 0;
            try{
            //connect to DB
            Connection con = GetConnection();
            
            //Statement for quirying database
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT PRIMARY_SERVICE,SESSION_DATE, RATE_VISIT, WAIT_TIME, FEEDBACK FROM SURVEY WHERE YSU_ID = "+YSUID+";");
            
            // Convert to Java-usable String and set Output variable to reflect resaults
            while (rs.next()){
                slist[count] = new Survey(rs.getString("PRIMARY_SERVICE"),rs.getString("SESSION_DATE"),rs.getString("RATE_VISIT"),rs.getString("WAIT_TIME"),rs.getString("FEEDBACK"));
                count++;
            }
        }catch (Exception e){System.out.println("Failed to get survey data");} 
        return slist;
    }
        //getSessionDates/Notes methods, pass YSUID int, return String
    /**
     * Returns dates that a student visited the MAC
     * @param inYSUID
     * YSU student ID as int
     * @return
     * String, session dates in format (YYYY-MM-DD)
     * @throws Exception 
     */
    public static String getSessionDates(int inYSUID) throws Exception{
        String Output = ""; 
        try{
            //connect to DB
            Connection con = GetConnection();
            
            //Statement for quirying database
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT SESSION_DATE FROM SESSIONS WHERE YSU_ID = "+inYSUID+";");
            
            // Convert to Java-usable String and set Output variable to reflect resaults
            while (rs.next()){
                Output = Output + "\n" + rs.getString("SESSION_DATE");
            }       
        }catch (Exception e){System.out.println("Failed to get session data");} 
        return Output;
    }
        /**
     * Returns all notes for a student who visited the MAC
     * @param inYSUID
     * YSU student ID as int
     * @return
     * String, Notes from the tutoring session
     * @throws Exception 
     */
    public static String getSessionNotes(int inYSUID) throws Exception{
        String Output = ""; 
        try{
            //connect to DB
            Connection con = GetConnection();
            
            //Statement for quirying database
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT NOTES FROM SESSIONS WHERE YSU_ID = "+inYSUID+";");
            
            // Convert to Java-usable String and set Output variable to reflect resaults
            while (rs.next()){
                Output = Output + "\n" + rs.getString("NOTES");
            }       
        }catch (Exception e){System.out.println("Failed to get session data");} 
        return Output;
    }
    /**
     * Combination of getSessionDates and getSession Notes.
     * @param inYSUID
     * YSU student ID as int
     * @return
     * String, Date + NOTES new line until ALL dates and notes have been returned.
     * @throws Exception 
     */
    public static Session[] getSessionDatesAndNotes(String inYSUID) throws Exception{
    Session[] slist = new Session[database.getSessionsSize(inYSUID)];
    int count = 0;
        try{
            //connect to DB
            Connection con = GetConnection();
            
            //Statement for quirying database
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT SESSION_DATE, NOTES FROM SESSIONS WHERE YSU_ID = "+inYSUID+";");
            
            // Convert to Java-usable String and set Output variable to reflect resaults
            while (rs.next()){
                slist[count] = new Session(rs.getString("SESSION_DATE"),rs.getString("NOTES"));
                count++;
            }       
        }catch (Exception e){System.out.println("Failed to get session data");} 
        return slist;
    }
    public static int getSessionsSize(String YSUID) throws Exception{
        Connection con = GetConnection();
        Statement stmt = con.createStatement();
                    ResultSet rs = stmt.executeQuery("SELECT count(*) AS size FROM sessions WHERE YSU_ID =" + YSUID +";");
            rs.next();
            int size = rs.getInt("size");
            return size;}
        public static int getSurveySize(String YSUID) throws Exception{
        Connection con = GetConnection();
        Statement stmt = con.createStatement();
                    ResultSet rs = stmt.executeQuery("SELECT count(*) AS size FROM survey WHERE YSU_ID =" + YSUID +";");
            rs.next();
            int size = rs.getInt("size");
            return size;}

}

