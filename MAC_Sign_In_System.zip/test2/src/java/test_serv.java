/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;


/**
 *
 * @author djd51
 */
public class test_serv extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet test_serv</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet test_serv at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                   doPost(request,response);

    }
    
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * This servlet takes in the registration form from the homepage.
     * Will display the questions.html page upon a successful check_in.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
               // Set response content type
      response.setContentType("text/html");
        String num = null;
        String Course = request.getParameter("RegCourseName");
        String first = request.getParameter("FirstName");
        String last = request.getParameter("LastName");
        String ID = request.getParameter("RegStudentId");
       
               if("".equals(first) || "".equals(last) || "".equals(ID)){
              JOptionPane.showMessageDialog(null, "Please fill out all fields to register student.");
          RequestDispatcher rs = request.getRequestDispatcher("MAC_signin.html");
         rs.include(request, response);}
                else if(ID.length() != 9){
                    JOptionPane.showMessageDialog(null,"YSU ID should be in form: Y00XXXXXX.");
                     RequestDispatcher rs = request.getRequestDispatcher("MAC_signin.html");
                    rs.include(request, response);}
                else if(!ID.startsWith("Y00")){
                    JOptionPane.showMessageDialog(null,"YSU ID should be in form: Y00XXXXXX.");
                    RequestDispatcher rs = request.getRequestDispatcher("MAC_signin.html");
                    rs.include(request, response);
                }
                else{ 
                    try {
                   num = ID.substring(3);
                    String student = first+last+num;
           if(!database.GetStudentData(num).equals(student)){
             database.SetStudentData(first, last, num);
           JOptionPane.showMessageDialog(null,"Student Successfully Registered");
           SimpleDateFormat DateFormat = new SimpleDateFormat("yyyyMMdd");             
        String TodayRaw  = DateFormat.format(new Date());
           SimpleDateFormat TimeFormat = new SimpleDateFormat("HHmmss");
           String RightNowRaw = TimeFormat.format(new Date());
           database.CreateSession(num, TodayRaw,RightNowRaw,Course);
           RequestDispatcher rs = request.getRequestDispatcher("MAC_signin.html");
           rs.include(request, response);
           
           }
           else{
               JOptionPane.showMessageDialog(null,"Student Already Registered,Next time you can use the Check-In form");
               SimpleDateFormat DateFormat = new SimpleDateFormat("yyyyMMdd");             
        String TodayRaw  = DateFormat.format(new Date());
                SimpleDateFormat TimeFormat = new SimpleDateFormat("HHmmss");
           String RightNowRaw = TimeFormat.format(new Date());
           database.CreateSession(num, TodayRaw,RightNowRaw,Course);
           RequestDispatcher rs = request.getRequestDispatcher("MAC_signin.html");
           rs.include(request, response);
           }
              /*
              Send all string vars to corresponding database methods
              which is duplicate_check first,then session_create
              */
          } catch (Exception ex) {
              Logger.getLogger(test_serv.class.getName()).log(Level.SEVERE, null, ex);
          }
      
    }}

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    protected database database_connection() throws SQLException, ClassNotFoundException{
        database base = new database();
        return base;}

}
