/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author djd51
 */
public class Student {
    private String first,last,num;
    
    public Student(String first, String last,String num){
        this.first = first;
        this.last = last;
        this.num = num;
    }
    
    public String get_first(){
        return first;}
    public String get_last(){
        return last;}
    public String get_num(){
        return num;}
}
